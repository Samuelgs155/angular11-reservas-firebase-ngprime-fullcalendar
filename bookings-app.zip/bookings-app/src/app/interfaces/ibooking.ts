export interface IBooking {
    name: string,
    date: Date,
    service: string,
    title: string,
    className: string
}
