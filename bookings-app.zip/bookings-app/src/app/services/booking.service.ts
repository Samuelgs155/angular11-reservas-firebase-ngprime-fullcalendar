import { IBooking } from './../interfaces/ibooking';
import { Booking } from './../models/booking';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/internal/operators';
import { forEach, keys, orderBy } from 'lodash-es';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor(private http: HttpClient) { }

  /**
   * Obtengo las reservas de firebase
   */
  getBookings(): Observable<IBooking[]> {

    let headers = new HttpHeaders();
    headers = headers.set('Content-type', 'application/json');

    // IMPORTANTE: por temas de seguridad, se deshabilitara esta ruta, crea tu propio proyecto firebase
    const url = 'https://booking-app-f947e.firebaseio.com/bookings.json';

    return this.http.get<IBooking[]>(url, { headers: headers }).pipe(
      map(data => {
        let bookings = [];
        if (data) {
          console.log(data);
          // Obtengo el dia de hoy
          const today = new Date();
          // Recorro las llaves de la lista (ids firebase)
          forEach(keys(data), key => {
            // Creo el booking
            const booking = new Booking(data[key]);
            // Creo la fecha
            const bookingDate = new Date(booking.date);
            // Si la fecha es menor que hoy, no se mete
            if (bookingDate.getTime() >= today.getTime()) {
              bookings.push(booking.getData());
            }

          })
        }
        // Ordeno las reservas por fecha
        bookings = orderBy(bookings, b => b.date)
        return bookings;
      })
    )
  }

  /**
   * Añado la reserva a firebase
   * @param booking reserva a añadir
   */
  addBooking(booking: Booking) {

    let headers = new HttpHeaders();
    headers = headers.set('Content-type', 'application/json');

    // IMPORTANTE: por temas de seguridad, se deshabilitara esta ruta, crea tu propio proyecto firebase
    const url = 'https://booking-app-f947e.firebaseio.com/bookings.json';

    // Pasamos el objeto a cadena con JSON.stringify
    const body = JSON.stringify(booking.getData());

    return this.http.post(url, body, { headers: headers });

  }


}
