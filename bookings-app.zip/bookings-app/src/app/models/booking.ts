import { IBooking } from '../interfaces/ibooking';
import { set, get } from 'lodash-es';

export class Booking implements IBooking{

    constructor(data){
        set(this, 'data', data);
    }

    get name(){
        return get(this, 'data.name');
    }
    
    get date(){
        return get(this, 'data.date');
    }
    
    get service(){
        return get(this, 'data.service');
    }

    get title(){
        return get(this, 'data.title');
    }

    set title(value: string){
        set(this, 'data.title', value);
    }

    get className(){
        return get(this, 'data.className');
    }

    set className(value: string){
        set(this, 'data.className', value);
    }

    getData(){
        return get(this, 'data')
    }

}

