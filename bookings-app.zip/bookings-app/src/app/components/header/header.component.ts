import { AuthService } from './../../services/auth.service';
import { Router } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(
    private modalService: NgbModal,
    private router: Router,
    public authService: AuthService
  ) { }

  ngOnInit() {
  }

  /**
   * Abro el modal de login (componente dinamico)
   */
  openLogin() {
    this.modalService.open(LoginComponent);
  }

  /**
   * Nos desloguea de la app, usando localstorage
   */
  logout() {
    localStorage.removeItem("logged");
    this.router.navigate(['/add-booking'])
  }

}
