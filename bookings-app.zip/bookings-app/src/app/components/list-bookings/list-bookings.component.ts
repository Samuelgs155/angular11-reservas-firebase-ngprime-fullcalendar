import { TranslateService } from './../../services/translate.service';


import { Router } from '@angular/router';
import { AuthService } from './../../services/auth.service';
import { BookingService } from './../../services/booking.service';
import { Booking } from './../../models/booking';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { IBooking } from 'src/app/interfaces/ibooking';

import interactionPlugin from '@fullcalendar/interaction';
import timeGridPlugin from '@fullcalendar/timegrid';
import dayGridPlugin from '@fullcalendar/daygrid';
import esLocale from '@fullcalendar/core/locales/es';
import Tooltip from 'tooltip.js';

@Component({
  selector: 'app-list-bookings',
  templateUrl: './list-bookings.component.html',
  styleUrls: ['./list-bookings.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ListBookingsComponent implements OnInit {

  // Atributos
  public listBookings: IBooking[];
  public loadBookings: boolean;

  public options: any;

  constructor(
    private bookingService: BookingService,
    private authService: AuthService,
    private router: Router,
    private translateService: TranslateService
  ) {
    this.listBookings = [];
    this.loadBookings = false;

    this.options = {
      plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
      defaultDate: new Date(),
      locale: esLocale,
      header: {
        left: 'prev,next',
        center: 'title',
        right: 'dayGridMonth, dayGridWeek, dayGridDay'
      },
      editable: false,
      eventRender: (e) => {
        console.log(e);
        var tooltip = new Tooltip(e.el, {
          title: "<h6>" + translateService.getTranslate('label.client') + ' ' + e.event.extendedProps.name + "</h6>" + translateService.getTranslate('label.service.selected') + ' ' + translateService.getTranslate(e.event.extendedProps.service),
          placement: 'top',
          trigger: 'hover',
          container: 'body',
          html: true
        })
      }
    }
  }

  ngOnInit() {

    // Si estoy logueado, recojo las reservas
    if (this.authService.isAuthenticated()) {
      this.bookingService.getBookings().subscribe(list => {
        this.listBookings = list;
        this.loadBookings = true;
      }, error => {
        console.log("No se ha podido recuperar los bookings: " + error);
        this.loadBookings = true;
      })
    } else {
      // Sino vuelvo al inicio
      this.router.navigate(['/add-booking'])
    }

  }

}
