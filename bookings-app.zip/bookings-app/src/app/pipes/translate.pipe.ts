import { TranslateService } from './../services/translate.service';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'translate'
})
export class TranslatePipe implements PipeTransform {

  // Uso al servicio de traduccion
  constructor(private translateService: TranslateService){}

  transform(value: any): any {
    // Traduzco la palabra pasada
    return this.translateService.getTranslate(value) ?  this.translateService.getTranslate(value) : '';
  }

}
